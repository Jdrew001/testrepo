# Reading Plan Tracker

_Track Bible reading/study progress across books and passages._

## Active Plans

_(No active plans yet. Start one by telling Ezra: "Start a reading plan for Romans" or "I want to study through the Gospel of John")_

## Format

When a plan is added, it follows this structure:

```
### [Book Name] — [Type: study / read-through / sermon series]
- Started: YYYY-MM-DD
- Status: in-progress | paused | completed
- Current position: [chapter:verse]
- Passages completed:
  - [ ] Chapter 1:1-17 — (date)
  - [ ] Chapter 1:18-32 — (date)
  ...
- Notes: (anything relevant — pace, focus areas, skip list)
```

## Completed Plans

_(None yet)_

---

_Ezra updates this file after each study session. Drew can also edit it directly._
