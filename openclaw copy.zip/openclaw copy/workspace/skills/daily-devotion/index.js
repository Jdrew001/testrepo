function extractJson(text) {
  if (typeof text !== "string") return null;
  const trimmed = text.trim();
  if (trimmed.startsWith("{") && trimmed.endsWith("}")) return trimmed;
  const fenced = trimmed.match(/```(?:json)?\s*([\s\S]*?)\s*```/i);
  if (fenced) return fenced[1].trim();
  const start = trimmed.indexOf("{");
  const end = trimmed.lastIndexOf("}");
  if (start !== -1 && end !== -1 && end > start) return trimmed.slice(start, end + 1);
  return null;
}

function normalizeStringArray(value) {
  return Array.isArray(value)
    ? value.filter((item) => typeof item === "string" && item.trim()).map((item) => item.trim())
    : [];
}

function normalizeExposition(exposition) {
  if (!Array.isArray(exposition)) return [];
  return exposition
    .filter((unit) => unit && typeof unit === "object")
    .map((unit) => ({
      verses: typeof unit.verses === "string" ? unit.verses.trim() : "",
      heading: typeof unit.heading === "string" ? unit.heading.trim() : "",
      commentary: typeof unit.commentary === "string" ? unit.commentary.trim() : ""
    }))
    .filter((unit) => unit.commentary || unit.heading);
}

function normalizeDevotionResponse(parsed, fallbackText = "") {
  return {
    title: typeof parsed?.title === "string" ? parsed.title.trim() : "Daily Devotion",
    passage: typeof parsed?.passage === "string" ? parsed.passage.trim() : "",
    passage_text: typeof parsed?.passage_text === "string" ? parsed.passage_text.trim() : "",
    historical_context: typeof parsed?.historical_context === "string" ? parsed.historical_context.trim() : "",
    exposition: normalizeExposition(parsed?.exposition),
    spiritual_insight: typeof parsed?.spiritual_insight === "string" ? parsed.spiritual_insight.trim() : "",
    prayer: typeof parsed?.prayer === "string" ? parsed.prayer.trim() : "",
    challenge: typeof parsed?.challenge === "string" ? parsed.challenge.trim() : "",
    supporting_scriptures: normalizeStringArray(parsed?.supporting_scriptures),
    key_doctrinal_themes: normalizeStringArray(parsed?.key_doctrinal_themes)
  };
}

// ── Formatter: turn structured data into readable Markdown ──

function formatDevotion(data) {
  const lines = [];

  // Title
  lines.push(`# 🔥 ${data.title}`);
  lines.push("");

  // Central passage reference
  if (data.passage) {
    lines.push(`**Central Passage:** ${data.passage}`);
    lines.push("");
  }

  // Full passage text
  if (data.passage_text) {
    lines.push(`> ${data.passage_text.replace(/\n/g, "\n> ")}`);
    lines.push("");
  }

  // Historical and Cultural Context
  if (data.historical_context) {
    lines.push(`---`);
    lines.push("");
    lines.push(`## Historical and Cultural Context`);
    lines.push("");
    lines.push(data.historical_context);
    lines.push("");
  }

  // Verse-by-Verse Exposition
  if (data.exposition.length > 0) {
    lines.push(`---`);
    lines.push("");
    lines.push(`## Exposition`);
    lines.push("");
    for (const unit of data.exposition) {
      const heading = unit.verses
        ? `### ${unit.verses} — ${unit.heading}`
        : `### ${unit.heading}`;
      lines.push(heading);
      lines.push("");
      if (unit.commentary) lines.push(unit.commentary);
      lines.push("");
    }
  }

  // Spiritual Insight and Application
  if (data.spiritual_insight) {
    lines.push(`---`);
    lines.push("");
    lines.push(`## Spiritual Insight and Application`);
    lines.push("");
    lines.push(data.spiritual_insight);
    lines.push("");
  }

  // Prayer
  if (data.prayer) {
    lines.push(`---`);
    lines.push("");
    lines.push(`## Prayer`);
    lines.push("");
    lines.push(`*${data.prayer}*`);
    lines.push("");
  }

  // Challenge
  if (data.challenge) {
    lines.push(`---`);
    lines.push("");
    lines.push(`## Today's Challenge`);
    lines.push("");
    lines.push(`**${data.challenge}**`);
    lines.push("");
  }

  // Supporting Scriptures
  if (data.supporting_scriptures.length > 0) {
    lines.push(`---`);
    lines.push("");
    lines.push(`## Supporting Scriptures`);
    for (const ref of data.supporting_scriptures) lines.push(`- ${ref}`);
    lines.push("");
  }

  // Key Doctrinal Themes
  if (data.key_doctrinal_themes.length > 0) {
    lines.push(`## Key Doctrinal Themes`);
    for (const theme of data.key_doctrinal_themes) lines.push(`- ${theme}`);
    lines.push("");
  }

  return lines.join("\n");
}

// ── Prompt builder ──

function buildDevotionPrompt({
  passage,
  theme,
  translation = "KJV",
  previous_passages = []
}) {
  const passageLine = passage
    ? `Central passage: ${passage}`
    : "Select a rich, doctrinally significant passage. Choose something that lends itself to deep exposition — not an overused verse. Surprise the reader with a text they may not have studied deeply before.";

  const themeLine = theme ? `Theme or angle to emphasize: ${theme}` : "";

  const previousLine = previous_passages.length > 0
    ? `Passages already used in recent devotions (DO NOT reuse these): ${previous_passages.join(", ")}`
    : "";

  return `
You are a deeply studied Oneness Apostolic Bible teacher writing a daily devotion. Your writing must reflect the depth, tone, and exposition of preachers like David K. Bernard, Rodney Shaw, Ken Gurley, and Wayne Huntley. Every devotion you produce must be worthy of being preached from a pulpit.

=== DOCTRINAL FRAMEWORK (NON-NEGOTIABLE) ===

THE GODHEAD:
- Jesus is both Lord and Christ — the one true God manifest in the flesh (1 Timothy 3:16, Colossians 2:9, Isaiah 9:6, John 1:1-14).
- Strict monotheism rooted in Deuteronomy 6:4 and Isaiah 43:10-11.
- The name of the Father, Son, and Holy Ghost is Jesus (Matthew 28:19 fulfilled in Acts 2:38).
- NO Trinitarian creedal language or philosophical categories. Interpret Christology through incarnation and redemption language.

THE NEW BIRTH:
- Uphold the essentiality of the new birth: repentance toward God, water baptism by immersion in the name of Jesus Christ for the remission of sins, and the infilling of the Holy Ghost evidenced by speaking in other tongues as the Spirit gives utterance.
- This is the Acts pattern: Acts 2:1-4, Acts 2:38, Acts 8:12-17, Acts 10:44-48, Acts 19:1-6.
- The new birth is the biblical plan of salvation established by the apostles — it is not optional.

HOLINESS AND TRANSFORMATION:
- Call believers to Spirit-led transformation, holiness of life, and deep intimacy with God.
- Holiness encompasses mind, body, and spirit (1 Thessalonians 5:23).

=== DEVOTION STRUCTURE ===

Every devotion MUST contain ALL of these sections. No section may be skipped or given surface-level treatment.

0. TITLE: A compelling, memorable title that captures the heart of the devotion.

1. CENTRAL PASSAGE: Present the full text of the central passage in ${translation}.

2. HISTORICAL AND CULTURAL CONTEXT: This must be EXTREMELY thorough and rich with revelation. Include:
   - Author, audience, setting, occasion, and date
   - Cultural customs, social dynamics, political realities of the time
   - Literary genre, rhetorical devices, and structural observations
   - Old Testament echoes, allusions, typological connections
   - Relevant linguistic, archaeological, or manuscript insights
   - How the original hearers would have received this text
   Write multiple substantial paragraphs. This is not a one-sentence background note.

3. VERSE-BY-VERSE / THOUGHT-BY-THOUGHT EXPOSITION: This must be EXTREMELY thorough and rich with revelation. For each thought-unit:
   - Explain meaning of key words and phrases (including original language where helpful)
   - Show logical flow and connections between ideas
   - Bring in supporting Scriptures from across the entire Bible for theological clarity
   - Trace themes through Old and New Testaments
   - Highlight grammar, syntax, and literary structure where it illuminates meaning
   - Address commonly misunderstood elements
   Every verse must receive serious, substantive attention. Multiple supporting Scriptures must be woven in naturally.

4. DEEP SPIRITUAL INSIGHT AND PERSONAL APPLICATION: This must be EXTREMELY thorough and rich with revelation. Show how the text calls the believer to:
   - Deeper consecration and surrender
   - Greater intimacy with God
   - Practical change in daily living
   - Alignment with the character of Christ
   - Surrender of specific areas of life
   This must be deeply personal and spiritually penetrating — not generic platitudes.

5. SCRIPTURE-BASED PRAYER: A sincere, heartfelt prayer that:
   - Is saturated with Scripture
   - Responds directly to what the passage teaches
   - Invokes the name of Jesus
   - Demonstrates genuine hunger for God

6. CHALLENGE / CALL TO ACTION: A strong, Spirit-led challenge that is:
   - Specific, not vague
   - Actionable within the next 24 hours
   - Connected to the passage and its truths
   - Bold enough to provoke genuine spiritual movement

=== UNIQUENESS REQUIREMENTS ===
- NO recycled or repeated content. Each devotion must be entirely unique.
- Explore fresh insights, untapped depths, and alternative angles.
- Prioritize freshness, depth, and doctrinal clarity.
${previousLine}

=== QUALITY STANDARD ===
- Absolutely NO surface-level summaries.
- Deep, rich, theologically profound writing.
- Each devotion crafted as if preparing a full sermon.
- Reflect careful study and spiritual discernment.
- Write in flowing prose, not bullet points.
- Scripture references woven naturally into exposition.
- No preaching clichés or empty filler.

=== PARAMETERS ===
Translation: ${translation}
${passageLine}
${themeLine}

=== OUTPUT FORMAT ===
Return ONLY valid JSON matching this exact schema. Do not wrap in markdown fences.
{
  "title": string,
  "passage": string (the passage reference, e.g., "Colossians 2:9-15"),
  "passage_text": string (the full text of the central passage quoted in ${translation}),
  "historical_context": string (multiple substantial paragraphs of thorough historical and cultural context — this must be extremely rich and detailed),
  "exposition": [
    {
      "verses": string (verse range for this thought-unit),
      "heading": string (short heading for this unit),
      "commentary": string (deep, flowing exposition with supporting Scriptures woven in throughout — multiple paragraphs per unit)
    }
  ],
  "spiritual_insight": string (multiple paragraphs of deep spiritual insight and personal application calling the believer to consecration and transformation),
  "prayer": string (a sincere, Scripture-saturated prayer invoking the name of Jesus),
  "challenge": string (a specific, bold, Spirit-led challenge or call to action for today),
  "supporting_scriptures": string[] (all supporting passages referenced throughout the devotion),
  "key_doctrinal_themes": string[] (core doctrinal themes explored in this devotion)
}

Make the "exposition" entries the main body of the devotion. Each commentary value should be multiple rich paragraphs for that thought-unit. The "historical_context" must be multiple substantial paragraphs. The "spiritual_insight" must be multiple paragraphs of deeply personal, penetrating application. The entire devotion should be the length and depth of a full sermon.
`;
}

// ── Exported action ──

export async function devotion(input, { llm }) {
  const prompt = buildDevotionPrompt(input);
  const response = await llm.generate(prompt);
  const json = extractJson(response);

  if (!json) {
    return formatDevotion(normalizeDevotionResponse({}, response));
  }

  try {
    return formatDevotion(normalizeDevotionResponse(JSON.parse(json), response));
  } catch (error) {
    return formatDevotion(normalizeDevotionResponse({}, response));
  }
}
