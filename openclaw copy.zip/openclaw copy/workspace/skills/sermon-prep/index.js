function extractJson(text) {
  if (typeof text !== "string") return null;
  const trimmed = text.trim();
  if (trimmed.startsWith("{") && trimmed.endsWith("}")) return trimmed;
  const fenced = trimmed.match(/```(?:json)?\s*([\s\S]*?)\s*```/i);
  if (fenced) return fenced[1].trim();
  const start = trimmed.indexOf("{");
  const end = trimmed.lastIndexOf("}");
  if (start !== -1 && end !== -1 && end > start) return trimmed.slice(start, end + 1);
  return null;
}

function normalizeStringArray(value) {
  return Array.isArray(value)
    ? value.filter((item) => typeof item === "string" && item.trim()).map((item) => item.trim())
    : [];
}

function normalizeIntro(intro) {
  if (!intro || typeof intro !== "object") {
    return { scripture_references: [], narrative_setup: "", key_quotes: [], rhetorical_build: "", thesis: "" };
  }
  return {
    scripture_references: normalizeStringArray(intro.scripture_references),
    narrative_setup: typeof intro.narrative_setup === "string" ? intro.narrative_setup.trim() : "",
    key_quotes: normalizeStringArray(intro.key_quotes),
    rhetorical_build: typeof intro.rhetorical_build === "string" ? intro.rhetorical_build.trim() : "",
    thesis: typeof intro.thesis === "string" ? intro.thesis.trim() : ""
  };
}

function normalizePoints(points) {
  if (!Array.isArray(points)) return [];
  return points
    .filter((p) => p && typeof p === "object")
    .map((p, i) => ({
      number: typeof p.number === "number" ? p.number : i + 1,
      label: typeof p.label === "string" ? p.label.trim() : "",
      anchor_verse: typeof p.anchor_verse === "string" ? p.anchor_verse.trim() : "",
      development: typeof p.development === "string" ? p.development.trim() : "",
      cultural_insight: typeof p.cultural_insight === "string" ? p.cultural_insight.trim() : "",
      connection_to_theme: typeof p.connection_to_theme === "string" ? p.connection_to_theme.trim() : ""
    }))
    .filter((p) => p.label || p.development);
}

function normalizeConclusion(conc) {
  if (!conc || typeof conc !== "object") {
    return { closing_scripture: "", word_study: "", personal_application: "", circle_back: "", final_call: "" };
  }
  return {
    closing_scripture: typeof conc.closing_scripture === "string" ? conc.closing_scripture.trim() : "",
    word_study: typeof conc.word_study === "string" ? conc.word_study.trim() : "",
    personal_application: typeof conc.personal_application === "string" ? conc.personal_application.trim() : "",
    circle_back: typeof conc.circle_back === "string" ? conc.circle_back.trim() : "",
    final_call: typeof conc.final_call === "string" ? conc.final_call.trim() : ""
  };
}

function normalizeOutlineResponse(parsed, fallback = "") {
  return {
    title: typeof parsed?.title === "string" ? parsed.title.trim() : "",
    primary_passage: typeof parsed?.primary_passage === "string" ? parsed.primary_passage.trim() : "",
    supporting_passages: normalizeStringArray(parsed?.supporting_passages),
    theme: typeof parsed?.theme === "string" ? parsed.theme.trim() : "",
    introduction: normalizeIntro(parsed?.introduction),
    points: normalizePoints(parsed?.points),
    conclusion: normalizeConclusion(parsed?.conclusion),
    cross_references: normalizeStringArray(parsed?.cross_references),
    key_terms: normalizeStringArray(parsed?.key_terms),
    preacher_notes: normalizeStringArray(parsed?.preacher_notes)
  };
}

function normalizeSeriesResponse(parsed, fallback = "") {
  return {
    series_title: typeof parsed?.series_title === "string" ? parsed.series_title.trim() : "",
    overview: typeof parsed?.overview === "string" ? parsed.overview.trim() : "",
    weeks: Array.isArray(parsed?.weeks)
      ? parsed.weeks
          .filter((w) => w && typeof w === "object")
          .map((w, i) => ({
            week: typeof w.week === "number" ? w.week : i + 1,
            title: typeof w.title === "string" ? w.title.trim() : "",
            passage: typeof w.passage === "string" ? w.passage.trim() : "",
            focus: typeof w.focus === "string" ? w.focus.trim() : "",
            key_verse: typeof w.key_verse === "string" ? w.key_verse.trim() : ""
          }))
      : [],
    arc: typeof parsed?.arc === "string" ? parsed.arc.trim() : ""
  };
}

// ── Formatters: turn structured data into readable Markdown ──

function formatOutline(data) {
  const lines = [];

  if (data.title) lines.push(`# 🎤 ${data.title}`);
  if (data.primary_passage) lines.push(`**Primary Text:** ${data.primary_passage}`);
  if (data.supporting_passages.length > 0) {
    lines.push(`**Supporting Passages:** ${data.supporting_passages.join("; ")}`);
  }
  if (data.theme) lines.push(`**Theme:** ${data.theme}`);
  if (lines.length > 0) lines.push("");

  const intro = data.introduction;
  if (intro.scripture_references.length > 0 || intro.narrative_setup || intro.thesis) {
    lines.push(`## Introduction`);
    if (intro.scripture_references.length > 0) {
      for (const ref of intro.scripture_references) lines.push(ref);
      lines.push("");
    }
    if (intro.narrative_setup) {
      lines.push(intro.narrative_setup);
      lines.push("");
    }
    if (intro.key_quotes.length > 0) {
      for (const quote of intro.key_quotes) {
        lines.push(`> ${quote}`);
        lines.push("");
      }
    }
    if (intro.rhetorical_build) {
      lines.push(intro.rhetorical_build);
      lines.push("");
    }
    if (intro.thesis) {
      lines.push(`**${intro.thesis}**`);
      lines.push("");
    }
  }

  if (data.points.length > 0) {
    for (const pt of data.points) {
      lines.push(`## Point ${pt.number} — ${pt.label}`);
      lines.push("");
      if (pt.anchor_verse) {
        lines.push(`> ${pt.anchor_verse}`);
        lines.push("");
      }
      if (pt.development) {
        lines.push(pt.development);
        lines.push("");
      }
      if (pt.cultural_insight) {
        lines.push(`*${pt.cultural_insight}*`);
        lines.push("");
      }
    }
  }

  const conc = data.conclusion;
  if (conc.closing_scripture || conc.word_study || conc.personal_application || conc.final_call) {
    lines.push(`## Conclusion`);
    if (conc.closing_scripture) {
      lines.push(`> ${conc.closing_scripture}`);
      lines.push("");
    }
    if (conc.word_study) {
      lines.push(conc.word_study);
      lines.push("");
    }
    if (conc.personal_application) {
      lines.push(conc.personal_application);
      lines.push("");
    }
    if (conc.circle_back) {
      lines.push(conc.circle_back);
      lines.push("");
    }
    if (conc.final_call) {
      lines.push(`**${conc.final_call}**`);
      lines.push("");
    }
  }

  if (data.cross_references.length > 0) {
    lines.push(`## Cross-References`);
    for (const ref of data.cross_references) lines.push(`- ${ref}`);
    lines.push("");
  }

  if (data.key_terms.length > 0) {
    lines.push(`## Key Terms`);
    for (const term of data.key_terms) lines.push(`- ${term}`);
    lines.push("");
  }

  if (data.preacher_notes.length > 0) {
    lines.push(`## Preacher's Notes`);
    for (const note of data.preacher_notes) lines.push(`- ${note}`);
    lines.push("");
  }

  return lines.join("\n");
}

function formatSeries(data) {
  const lines = [];

  if (data.series_title) lines.push(`# 📅 ${data.series_title}`);
  if (data.overview) {
    lines.push("");
    lines.push(data.overview);
  }
  lines.push("");

  if (data.weeks.length > 0) {
    lines.push(`## Weekly Breakdown`);
    lines.push("");
    for (const w of data.weeks) {
      lines.push(`### Week ${w.week}: ${w.title}`);
      if (w.passage) lines.push(`**Passage:** ${w.passage}`);
      if (w.focus) lines.push(`**Focus:** ${w.focus}`);
      if (w.key_verse) lines.push(`**Key verse:** ${w.key_verse}`);
      lines.push("");
    }
  }

  if (data.arc) {
    lines.push(`## Series Arc`);
    lines.push(data.arc);
    lines.push("");
  }

  return lines.join("\n");
}

function formatRefine(data) {
  const lines = [];

  lines.push(`# ✏️ Revised Outline`);
  lines.push("");
  if (data.revised_outline) lines.push(data.revised_outline);
  lines.push("");

  if (data.changes && data.changes.length > 0) {
    lines.push(`## What Changed`);
    for (const change of data.changes) lines.push(`- ${change}`);
    lines.push("");
  }

  if (data.suggestions && data.suggestions.length > 0) {
    lines.push(`## Additional Suggestions`);
    for (const s of data.suggestions) lines.push(`- ${s}`);
    lines.push("");
  }

  return lines.join("\n");
}

// ── Core logic ──

async function generateResponse(llm, prompt, normalizer) {
  const response = await llm.generate(prompt);
  const json = extractJson(response);
  if (!json) return normalizer({}, response);
  try {
    return normalizer(JSON.parse(json), response);
  } catch {
    return normalizer({}, response);
  }
}

function buildOutlinePrompt({
  passage,
  topic,
  sermon_type = "expository",
  audience,
  length = "standard",
  translation = "KJV",
  focus = []
}) {
  const audienceLine = audience ? `Audience: ${audience}` : "Audience: general Sunday morning congregation";
  const focusLine = Array.isArray(focus) && focus.length > 0 ? `Focus themes: ${focus.join(", ")}` : "";
  const topicLine = topic ? `Topic/Title: ${topic}` : "";

  const lengthGuide = {
    short: "15-20 minutes (2 points, concise)",
    standard: "25-35 minutes (2-3 points, moderate depth)",
    extended: "40-50 minutes (3-4 points, deep exposition)"
  };

  return `
You are an Apostolic sermon preparation partner. You build text-driven, Scripture-anchored sermon outlines that follow a specific structural pattern.

=== STRUCTURAL PATTERN ===

The sermon must follow this flow:

INTRODUCTION:
- Open with 2-4 Scripture references listed up front that ground the sermon
- Tell the STORY behind the text — set the scene with historical and emotional context. This is not a one-liner hook; it's multiple paragraphs that draw the listener into the world of the passage
- Quote key verses IN FULL within the narrative flow (not just cite references)
- Use short parallel lines and repetition to build rhetorical rhythm (e.g., "It was not a moment of strength. It was not a moment of dignity. It was a moment of survival.")
- Land on a clear thesis — a memorable, standalone declaration that the entire sermon will develop

POINTS (typically 2-3):
Each point follows this shape:
- A clear, descriptive title (e.g., "God's Goodness Is Revealed Through His Mercy")
- Open with the anchor verse QUOTED IN FULL
- Develop the point by weaving Scripture, narrative, and explanation together — multiple supporting verses quoted inline throughout, not just one verse range
- Illustrations come from Scripture narrative or real life and are WOVEN INTO the flow (not called out as a sidebar). The story IS the exposition
- Include cultural or historical background where it deepens understanding
- Use rhetorical pause points — short parallel lines, repetition, direct address ("Think about that.")
- Close each point by tying back to the central thesis

CONCLUSION:
- A closing Scripture that wraps the message (can echo the opening)
- A word study or deeper insight on a key term
- Application through parallel/repetitive lines that make it personal
- Circle back to the opening Scripture or thesis for completeness
- End with an invitation to respond/experience — not a formulaic altar call, but a natural culmination of what the sermon has built

=== THEOLOGICAL FRAMEWORK ===
- Apostolic/Oneness: monotheistic baseline (Deut 6:4), incarnation Christology, Acts 2:38 salvation pattern
- Do not use creedal or Trinitarian philosophical categories unless explicitly asked
- Scripture woven into narrative, not bolted on as proof-texts

=== PARAMETERS ===
Translation: ${translation}
Sermon type: ${sermon_type}
Target length: ${lengthGuide[length] || lengthGuide.standard}
${audienceLine}
${topicLine}
${focusLine}

Primary passage: ${passage}

Return ONLY valid JSON matching this schema. Do not wrap in markdown fences.
{
  "title": string,
  "primary_passage": string,
  "supporting_passages": string[] (other passages referenced in the sermon),
  "theme": string (one sentence — the central truth this sermon declares),
  "introduction": {
    "scripture_references": string[] (2-4 Scripture references listed at the top),
    "narrative_setup": string (multi-paragraph story/context that opens the sermon — tell the story behind the text with historical and emotional detail),
    "key_quotes": string[] (key verses quoted in full within the introduction, formatted as 'Reference "Quote text"'),
    "rhetorical_build": string (short parallel lines and repetition that build momentum toward the thesis),
    "thesis": string (the central truth stated as a clear, standalone declaration)
  },
  "points": [
    {
      "number": integer,
      "label": string (descriptive point title),
      "anchor_verse": string (primary verse for this point quoted in full, formatted as 'Reference "Quote text"'),
      "development": string (multi-paragraph exposition weaving Scripture quoted inline, narrative, illustration, and rhetorical rhythm together — this is the body of the point),
      "cultural_insight": string (historical or cultural background that deepens the point, or empty string if not applicable),
      "connection_to_theme": string (how this point ties back to the central thesis — stated directly)
    }
  ],
  "conclusion": {
    "closing_scripture": string (a verse quoted in full that wraps the sermon),
    "word_study": string (deeper meaning of a key word or phrase from the closing verse),
    "personal_application": string (application using parallel/repetitive lines that make it personal),
    "circle_back": string (return to the opening Scripture or thesis for completeness),
    "final_call": string (invitation to respond — natural culmination, not formulaic)
  },
  "cross_references": string[] (all passages referenced throughout the sermon),
  "key_terms": string[] (important terms the preacher should understand),
  "preacher_notes": string[] (behind-the-scenes notes: things to study further, pitfalls, tone)
}
`;
}

function buildSeriesPrompt({ book, topic, weeks = 4, audience, translation = "KJV" }) {
  const audienceLine = audience ? `Audience: ${audience}` : "Audience: general congregation";
  const subject = book ? `Bible book: ${book}` : `Theme: ${topic}`;

  return `
You are an Apostolic sermon series planner. Build a multi-week preaching plan.

Principles:
- Each week should stand alone but contribute to a larger arc.
- Passage divisions should follow natural breaks in the text (don't split mid-argument).
- The series should build — later weeks should deepen what earlier weeks establish.
- Apostolic/Oneness theological framework throughout.

Translation: ${translation}
${subject}
Target weeks: ${weeks}
${audienceLine}

Return ONLY valid JSON:
{
  "series_title": string,
  "overview": string (what this series accomplishes — 2-3 sentences),
  "weeks": [
    {
      "week": integer,
      "title": string,
      "passage": string,
      "focus": string (one sentence — what this week is about),
      "key_verse": string
    }
  ],
  "arc": string (how the series builds week to week — 2-3 sentences)
}
`;
}

function buildRefinePrompt({ outline, feedback, passage }) {
  return `
You are an Apostolic sermon preparation partner. The preacher has an existing outline and wants it improved.

${passage ? `Primary passage: ${passage}` : ""}

Existing outline:
${outline}

Feedback from the preacher:
${feedback || "General improvement — strengthen weak points, tighten transitions, sharpen application."}

Improve the outline based on the feedback. Keep the Apostolic framework. Make every change purposeful.

Return ONLY valid JSON:
{
  "revised_outline": string (the full improved outline as readable text),
  "changes": string[] (what you changed and why — one item per change),
  "suggestions": string[] (additional ideas the preacher could consider)
}
`;
}

export async function outline(input, { llm }) {
  const prompt = buildOutlinePrompt(input);
  const data = await generateResponse(llm, prompt, normalizeOutlineResponse);
  return formatOutline(data);
}

export async function series(input, { llm }) {
  const prompt = buildSeriesPrompt(input);
  const data = await generateResponse(llm, prompt, normalizeSeriesResponse);
  return formatSeries(data);
}

export async function refine(input, { llm }) {
  const prompt = buildRefinePrompt(input);
  const response = await llm.generate(prompt);
  const json = extractJson(response);
  let result;
  if (!json) {
    result = { revised_outline: response, changes: [], suggestions: [] };
  } else {
    try {
      const parsed = JSON.parse(json);
      result = {
        revised_outline: typeof parsed.revised_outline === "string" ? parsed.revised_outline.trim() : response,
        changes: normalizeStringArray(parsed.changes),
        suggestions: normalizeStringArray(parsed.suggestions)
      };
    } catch {
      result = { revised_outline: response, changes: [], suggestions: [] };
    }
  }
  return formatRefine(result);
}
