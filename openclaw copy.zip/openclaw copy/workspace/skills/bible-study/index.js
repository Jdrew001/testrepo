function buildFocusLine(focus) {
  return Array.isArray(focus) && focus.length > 0
    ? `Focus themes or questions: ${focus.join(", ")}`
    : "Focus themes or questions: none";
}

function extractJson(text) {
  if (typeof text !== "string") {
    return null;
  }

  const trimmed = text.trim();

  if (trimmed.startsWith("{") && trimmed.endsWith("}")) {
    return trimmed;
  }

  const fencedMatch = trimmed.match(/```(?:json)?\s*([\s\S]*?)\s*```/i);
  if (fencedMatch) {
    return fencedMatch[1].trim();
  }

  const start = trimmed.indexOf("{");
  const end = trimmed.lastIndexOf("}");
  if (start !== -1 && end !== -1 && end > start) {
    return trimmed.slice(start, end + 1);
  }

  return null;
}

function normalizeStringArray(value) {
  return Array.isArray(value)
    ? value.filter((item) => typeof item === "string" && item.trim()).map((item) => item.trim())
    : [];
}

function normalizeObjectArray(value, fields) {
  if (!Array.isArray(value)) {
    return [];
  }

  return value
    .filter((item) => item && typeof item === "object")
    .map((item) => {
      const normalized = {};

      for (const field of fields) {
        normalized[field] = typeof item[field] === "string" ? item[field].trim() : "";
      }

      return normalized;
    })
    .filter((item) => fields.some((field) => item[field]));
}

function normalizeStudyResponse(parsed, fallbackSummary = "") {
  return {
    outline: normalizeObjectArray(parsed?.outline, ["verses", "label"]),
    exposition: normalizeObjectArray(parsed?.exposition, ["verses", "label", "commentary"]),
    summary: typeof parsed?.summary === "string" ? parsed.summary.trim() : fallbackSummary,
    context: typeof parsed?.context === "string" ? parsed.context.trim() : "",
    key_themes: normalizeStringArray(parsed?.key_themes),
    cross_references: normalizeStringArray(parsed?.cross_references),
    key_terms: normalizeStringArray(parsed?.key_terms),
    application: normalizeStringArray(parsed?.application),
    discussion_questions: normalizeStringArray(parsed?.discussion_questions)
  };
}

// ── Formatter: turn structured data into readable Markdown ──

function formatStudy(data, passage) {
  const lines = [];

  // Title
  const title = passage || "Bible Study";
  lines.push(`# 📖 ${title}`);
  lines.push("");

  // Context
  if (data.context) {
    lines.push(data.context);
    lines.push("");
  }

  // Thought-unit outline
  if (data.outline.length > 0) {
    lines.push(`## Outline`);
    for (const unit of data.outline) {
      lines.push(`- **${unit.verses}** — ${unit.label}`);
    }
    lines.push("");
  }

  // Exposition (the main body)
  if (data.exposition.length > 0) {
    lines.push(`---`);
    lines.push("");
    for (const unit of data.exposition) {
      const heading = unit.verses
        ? `## ${unit.verses} — ${unit.label}`
        : `## ${unit.label}`;
      lines.push(heading);
      lines.push("");
      if (unit.commentary) lines.push(unit.commentary);
      lines.push("");
    }
  }

  // Summary
  if (data.summary) {
    lines.push(`---`);
    lines.push("");
    lines.push(`## Summary`);
    lines.push(data.summary);
    lines.push("");
  }

  // Application
  if (data.application.length > 0) {
    lines.push(`## Application`);
    for (const point of data.application) lines.push(`- ${point}`);
    lines.push("");
  }

  // Key themes
  if (data.key_themes.length > 0) {
    lines.push(`## Key Themes`);
    for (const theme of data.key_themes) lines.push(`- ${theme}`);
    lines.push("");
  }

  // Cross-references
  if (data.cross_references.length > 0) {
    lines.push(`## Cross-References`);
    for (const ref of data.cross_references) lines.push(`- ${ref}`);
    lines.push("");
  }

  // Key terms
  if (data.key_terms.length > 0) {
    lines.push(`## Key Terms`);
    for (const term of data.key_terms) lines.push(`- ${term}`);
    lines.push("");
  }

  // Discussion questions
  if (data.discussion_questions.length > 0) {
    lines.push(`## Discussion Questions`);
    for (let i = 0; i < data.discussion_questions.length; i++) {
      lines.push(`${i + 1}. ${data.discussion_questions[i]}`);
    }
    lines.push("");
  }

  return lines.join("\n");
}

async function generateStudyResponse(llm, prompt, passage) {
  const response = await llm.generate(prompt);
  const json = extractJson(response);

  if (!json) {
    return formatStudy(normalizeStudyResponse({}, response), passage);
  }

  try {
    return formatStudy(normalizeStudyResponse(JSON.parse(json), response), passage);
  } catch (error) {
    return formatStudy(normalizeStudyResponse({}, response), passage);
  }
}

function buildStudyPrompt({
  passage,
  translation = "KJV",
  audience,
  depth = "standard",
  focus = [],
  include_cross_references = true,
  include_application = true,
  previousStudy
}) {
  const focusLine = buildFocusLine(focus);
  const audienceLine = audience ? `Audience: ${audience}` : "Audience: general";

  return `
Project Name
Apostolic Exposition (Verse-by-Verse)

Project Instructions (copy/paste)
Use these instructions for all Bible study requests unless explicitly overridden.

Role and Tone
You are my Apostolic Bible teacher. Teach with clarity, reverence, and confidence, but stay humble where Scripture is not explicit. Keep it conversational and flowing like a live Bible study, not bullet-point lecture notes.

Translation
Default to KJV unless I ask for another translation. Current translation: ${translation}.

Core Method
Explain Scripture verse-by-verse, but group verses into natural thought-units when they belong together. You must decide the groupings based on the author's flow of thought and grammar.

Required Output Format
1. Start by listing the thought-unit outline for the passage (just the verse ranges with short labels).
2. Then teach the passage in order, unit by unit.

For each thought-unit:
- Write a flowing paragraph exposition that walks through the verses in that unit in order.
- Show how each verse connects to what came before.
- Explain the meaning of important phrases in plain language.
- Keep the spotlight on the author's argument (look for "for," "therefore," "but," "so that," contrasts, repeated words).

Cross-References
Use cross-references naturally and sparingly. Include them when they truly clarify meaning or confirm doctrine. Do not dump a long list; work them into the exposition. When making a doctrinal claim, provide at least two supporting passages across the Bible. If cross references are disabled, do not include them.

Apostolic / Oneness Guardrails
Stay Scripture-first and Apostolic-friendly. Maintain a strong monotheistic baseline (Deut 6:4). Interpret Christology through incarnation and redemption language. When salvation or new birth is relevant, align with the Acts pattern (Acts 2, 8, 10, 19). Do not default to creedal language or Trinitarian philosophical categories unless explicitly asked to compare views. If a passage is commonly debated, briefly acknowledge alternative readings, but keep the exposition anchored in the text.

Depth Without Losing Flow
Go deep, but keep the writing smooth. Prioritize context, grammar and logic, and the paragraph's main idea. Do short word-meaning notes only when they actually affect interpretation. If there is an OT echo or allusion that matters, explain it simply.

Application
After finishing the passage, end with a short summary paragraph (what the text is saying as a whole) and a short application paragraph (what this demands of us). If application is disabled, omit it.

Style Rules
No heavy formatting. Minimal bullet points (only allowed in the initial thought-unit outline). No preaching cliches. No speculative claims presented as certainty. Keep it Bible-driven, not opinion-driven.

When I Ask Follow-Ups
If I ask "go deeper," deepen by expanding the thought-unit logic, adding stronger cross-references, clarifying key terms in context, and tracing the theme across Scripture without breaking the flowing exposition style.

Format for readability
Keep paragraphs short and readable. Avoid excessive line breaks. Do not use headings beyond the initial outline.

Output Requirements
Return ONLY valid JSON matching this schema. Do not wrap in markdown fences.
{
  "outline": [
    {
      "verses": string,
      "label": string
    }
  ],
  "exposition": [
    {
      "verses": string,
      "label": string,
      "commentary": string
    }
  ],
  "summary": string,
  "context": string,
  "key_themes": string[],
  "cross_references": string[],
  "key_terms": string[],
  "application": string[],
  "discussion_questions": string[]
}
If cross references are disabled, return an empty array for "cross_references".
If application is disabled, return an empty array for "application".
Keep each array item concise.
Make the "exposition" entries the main body of the study. Each commentary value should be a readable paragraph or short set of paragraphs for that thought-unit.

Request Context
Passage: ${passage}
${audienceLine}
Depth: ${depth}
${focusLine}
Cross references enabled: ${include_cross_references}
Application enabled: ${include_application}
${previousStudy ? `Prior study to deepen:\n${previousStudy}` : ""}
`;
}

export async function study(input, { llm }) {
  const prompt = buildStudyPrompt(input);
  return generateStudyResponse(llm, prompt, input.passage);
}

export async function go_deeper(
  {
    passage,
    previous_study,
    translation = "KJV",
    focus = []
  },
  { llm }
) {
  const prompt = buildStudyPrompt({
    passage,
    previousStudy: previous_study,
    translation,
    depth: "deep",
    focus,
    include_cross_references: true,
    include_application: true,
    audience: "returning Bible study student"
  }) + `

Follow-Up Requirement
This is a "go deeper" request. Deepen the study by strengthening the thought-unit logic, adding more precise cross-references, clarifying key terms in context, and tracing major themes across Scripture while keeping the same flowing exposition style.
`;

  return generateStudyResponse(llm, prompt, passage);
}