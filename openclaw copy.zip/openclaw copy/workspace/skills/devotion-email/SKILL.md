---
name: devotion-email
description: "Generates a daily Apostolic devotion and emails it to one or more recipients via Gmail SMTP. Use when the user asks to email a devotion, send a devotional, email daily bread, or deliver a morning devotion by email. Combines deep Oneness Apostolic biblical exposition with email delivery."
user-invocable: true
metadata: {"openclaw":{"emoji":"📧","requires":{"bins":["python3"],"env":["GMAIL_ADDRESS","GMAIL_APP_PASSWORD"]}}}
---

# Devotion Email

Use this skill when the user wants to **generate and email** a daily devotion. This skill combines the depth of the `daily-devotion` skill with email delivery via Gmail SMTP.

## How It Works

1. Generate a full daily devotion using the same Apostolic exposition standards as the `daily-devotion` skill.
2. Format the devotion as a clean, readable email body.
3. Send it via the `scripts/send-email.py` script.

## Prerequisites

The following environment variables must be set (in `~/.openclaw/.env` or exported in the shell):

- `GMAIL_ADDRESS` — Your Gmail address (e.g., `you@gmail.com`)
- `GMAIL_APP_PASSWORD` — A Gmail App Password (generate at https://myaccount.google.com/apppasswords)
- `EMAIL_RECIPIENT` — Default recipient email address (can be overridden per invocation)

## Workflow

When this skill is invoked:

1. **Generate the devotion** using the `devotion-email` action in `index.js`, which calls `llm.generate()` with the full Apostolic devotion prompt and returns formatted Markdown.
2. **Send the email** by running the send script:
   ```bash
   echo "<devotion_content>" | python3 ~/.openclaw/workspace/skills/devotion-email/scripts/send-email.py \
     --to "recipient@example.com" \
     --subject "Daily Devotion: <title>"
   ```
   The script reads the devotion body from stdin.
3. Report success or failure to the user.

## Doctrinal Framework

All devotions follow strict Oneness Apostolic doctrine:
- Jesus is the one true God manifest in the flesh (1 Timothy 3:16, Colossians 2:9)
- Strict monotheism (Deuteronomy 6:4, Isaiah 43:10-11)
- The new birth: repentance, water baptism in Jesus' name, Holy Ghost with tongues (Acts 2:38)
- Holiness of life as the fruit of a Spirit-filled walk

See the `daily-devotion` skill for the full doctrinal framework and exposition standards.

## Suggested Slash Command Usage

- `/devotion-email` — Generate and email a devotion (agent selects passage)
- `/devotion-email John 3:1-8` — Generate and email a devotion on a specific passage
- `/devotion-email --to someone@example.com` — Send to a specific recipient
- `/devotion-email --to someone@example.com,another@example.com` — Multiple recipients
- `/devotion-email --theme "the new birth"` — Devotion with a specific theme

## Multiple Recipients

The `--to` flag accepts comma-separated email addresses. If omitted, it uses the `EMAIL_RECIPIENT` environment variable.

## Error Handling

- If Gmail credentials are missing, the agent should inform the user and provide setup instructions.
- If email sending fails, the agent should still display the devotion content and report the email error.
- The devotion content is never lost — it is always shown to the user regardless of email success.
