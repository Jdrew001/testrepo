// ── Devotion Email Skill ──
// Generates a daily devotion via LLM, formats it, and provides it
// for email delivery via the companion send-email.py script.

function extractJson(text) {
  if (typeof text !== "string") return null;
  const trimmed = text.trim();
  if (trimmed.startsWith("{") && trimmed.endsWith("}")) return trimmed;
  const fenced = trimmed.match(/```(?:json)?\s*([\s\S]*?)\s*```/i);
  if (fenced) return fenced[1].trim();
  const start = trimmed.indexOf("{");
  const end = trimmed.lastIndexOf("}");
  if (start !== -1 && end !== -1 && end > start) return trimmed.slice(start, end + 1);
  return null;
}

function normalizeStringArray(value) {
  return Array.isArray(value)
    ? value.filter((item) => typeof item === "string" && item.trim()).map((item) => item.trim())
    : [];
}

function normalizeExposition(exposition) {
  if (!Array.isArray(exposition)) return [];
  return exposition
    .filter((unit) => unit && typeof unit === "object")
    .map((unit) => ({
      verses: typeof unit.verses === "string" ? unit.verses.trim() : "",
      heading: typeof unit.heading === "string" ? unit.heading.trim() : "",
      commentary: typeof unit.commentary === "string" ? unit.commentary.trim() : ""
    }))
    .filter((unit) => unit.commentary || unit.heading);
}

function normalizeDevotionResponse(parsed, fallbackText = "") {
  return {
    title: typeof parsed?.title === "string" ? parsed.title.trim() : "Daily Devotion",
    passage: typeof parsed?.passage === "string" ? parsed.passage.trim() : "",
    passage_text: typeof parsed?.passage_text === "string" ? parsed.passage_text.trim() : "",
    historical_context: typeof parsed?.historical_context === "string" ? parsed.historical_context.trim() : "",
    exposition: normalizeExposition(parsed?.exposition),
    spiritual_insight: typeof parsed?.spiritual_insight === "string" ? parsed.spiritual_insight.trim() : "",
    prayer: typeof parsed?.prayer === "string" ? parsed.prayer.trim() : "",
    challenge: typeof parsed?.challenge === "string" ? parsed.challenge.trim() : "",
    supporting_scriptures: normalizeStringArray(parsed?.supporting_scriptures),
    key_doctrinal_themes: normalizeStringArray(parsed?.key_doctrinal_themes)
  };
}

// ── Formatter: turn structured data into readable Markdown for email ──

function formatDevotion(data) {
  const lines = [];

  lines.push(`# 🔥 ${data.title}`);
  lines.push("");

  if (data.passage) {
    lines.push(`**Central Passage:** ${data.passage}`);
    lines.push("");
  }

  if (data.passage_text) {
    lines.push(`> ${data.passage_text.replace(/\n/g, "\n> ")}`);
    lines.push("");
  }

  if (data.historical_context) {
    lines.push(`---`);
    lines.push("");
    lines.push(`## Historical and Cultural Context`);
    lines.push("");
    lines.push(data.historical_context);
    lines.push("");
  }

  if (data.exposition.length > 0) {
    lines.push(`---`);
    lines.push("");
    lines.push(`## Exposition`);
    lines.push("");
    for (const unit of data.exposition) {
      const heading = unit.verses
        ? `### ${unit.verses} — ${unit.heading}`
        : `### ${unit.heading}`;
      lines.push(heading);
      lines.push("");
      if (unit.commentary) lines.push(unit.commentary);
      lines.push("");
    }
  }

  if (data.spiritual_insight) {
    lines.push(`---`);
    lines.push("");
    lines.push(`## Spiritual Insight and Application`);
    lines.push("");
    lines.push(data.spiritual_insight);
    lines.push("");
  }

  if (data.prayer) {
    lines.push(`---`);
    lines.push("");
    lines.push(`## Prayer`);
    lines.push("");
    lines.push(`*${data.prayer}*`);
    lines.push("");
  }

  if (data.challenge) {
    lines.push(`---`);
    lines.push("");
    lines.push(`## Today's Challenge`);
    lines.push("");
    lines.push(`**${data.challenge}**`);
    lines.push("");
  }

  if (data.supporting_scriptures.length > 0) {
    lines.push(`---`);
    lines.push("");
    lines.push(`## Supporting Scriptures`);
    for (const ref of data.supporting_scriptures) lines.push(`- ${ref}`);
    lines.push("");
  }

  if (data.key_doctrinal_themes.length > 0) {
    lines.push(`## Key Doctrinal Themes`);
    for (const theme of data.key_doctrinal_themes) lines.push(`- ${theme}`);
    lines.push("");
  }

  return lines.join("\n");
}

// ── Prompt builder ──

function buildDevotionPrompt({
  passage,
  theme,
  translation = "KJV",
  previous_passages = []
}) {
  const passageLine = passage
    ? `Central passage: ${passage}`
    : "Select a rich, doctrinally significant passage. Choose something that lends itself to deep exposition — not an overused verse. Surprise the reader with a text they may not have studied deeply before.";

  const themeLine = theme ? `Theme or angle to emphasize: ${theme}` : "";

  const previousLine = previous_passages.length > 0
    ? `Passages already used in recent devotions (DO NOT reuse these): ${previous_passages.join(", ")}`
    : "";

  return `
You are a deeply studied Oneness Apostolic Bible teacher writing a daily devotion to be sent by email. Your writing must reflect the depth, tone, and exposition of preachers like David K. Bernard, Rodney Shaw, Ken Gurley, and Wayne Huntley. Every devotion you produce must be worthy of being preached from a pulpit.

=== DOCTRINAL FRAMEWORK (NON-NEGOTIABLE) ===

THE GODHEAD:
- Jesus is both Lord and Christ — the one true God manifest in the flesh (1 Timothy 3:16, Colossians 2:9, Isaiah 9:6, John 1:1-14).
- Strict monotheism rooted in Deuteronomy 6:4 and Isaiah 43:10-11.
- The name of the Father, Son, and Holy Ghost is Jesus (Matthew 28:19 fulfilled in Acts 2:38).
- NO Trinitarian creedal language or philosophical categories. Interpret Christology through incarnation and redemption language.

THE NEW BIRTH:
- Uphold the essentiality of the new birth: repentance toward God, water baptism by immersion in the name of Jesus Christ for the remission of sins, and the infilling of the Holy Ghost evidenced by speaking in other tongues as the Spirit gives utterance.
- This is the Acts pattern: Acts 2:1-4, Acts 2:38, Acts 8:12-17, Acts 10:44-48, Acts 19:1-6.
- The new birth is the biblical plan of salvation established by the apostles — it is not optional.

HOLINESS AND TRANSFORMATION:
- Call believers to Spirit-led transformation, holiness of life, and deep intimacy with God.
- Holiness encompasses mind, body, and spirit (1 Thessalonians 5:23).

=== DEVOTION STRUCTURE ===

0. TITLE: A compelling, memorable title.

1. CENTRAL PASSAGE: Present the full text in ${translation}.

2. HISTORICAL AND CULTURAL CONTEXT: Extremely thorough — author, audience, setting, occasion, cultural customs, literary genre, OT echoes, linguistic/archaeological insights. Multiple substantial paragraphs.

3. VERSE-BY-VERSE / THOUGHT-BY-THOUGHT EXPOSITION: Extremely thorough. For each thought-unit: key words/phrases, logical flow, supporting Scriptures across the Bible, traced themes, grammar and structure, commonly misunderstood elements. Every verse gets serious attention.

4. DEEP SPIRITUAL INSIGHT AND PERSONAL APPLICATION: Deeply personal and spiritually penetrating. Consecration, intimacy with God, practical daily change, alignment with Christ's character.

5. SCRIPTURE-BASED PRAYER: Saturated with Scripture, invokes the name of Jesus, responds to the passage's teaching.

6. CHALLENGE / CALL TO ACTION: Specific, actionable within 24 hours, bold enough to provoke spiritual movement.

=== UNIQUENESS REQUIREMENTS ===
- Each devotion must be entirely unique. No recycled content.
- Explore fresh insights and untapped depths.
${previousLine}

=== QUALITY STANDARD ===
- Deep, rich, theologically profound writing.
- Flowing prose, not bullet points.
- Scripture references woven naturally.
- No preaching clichés or empty filler.

=== PARAMETERS ===
Translation: ${translation}
${passageLine}
${themeLine}

=== OUTPUT FORMAT ===
Return ONLY valid JSON:
{
  "title": string,
  "passage": string,
  "passage_text": string,
  "historical_context": string,
  "exposition": [
    {
      "verses": string,
      "heading": string,
      "commentary": string
    }
  ],
  "spiritual_insight": string,
  "prayer": string,
  "challenge": string,
  "supporting_scriptures": string[],
  "key_doctrinal_themes": string[]
}
`;
}

// ── Exported action ──

export async function send(input, { llm }) {
  const prompt = buildDevotionPrompt(input);
  const response = await llm.generate(prompt);
  const json = extractJson(response);

  let data;
  if (json) {
    try {
      data = normalizeDevotionResponse(JSON.parse(json), response);
    } catch {
      data = normalizeDevotionResponse({}, response);
    }
  } else {
    data = normalizeDevotionResponse({}, response);
  }

  const devotionMarkdown = formatDevotion(data);

  return {
    title: data.title,
    passage: data.passage,
    devotion_markdown: devotionMarkdown,
    _meta: {
      hint: "To send this devotion by email, run the send-email.py script with the devotion content piped to stdin."
    }
  };
}
