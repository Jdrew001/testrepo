# MEMORY.md - Long-Term Memory

_Ezra's curated memory. Significant events, patterns, lessons learned._

## Drew's Study History

_(Updated as studies are completed)_

## Recurring Themes & Questions

_(Patterns noticed across studies — topics Drew returns to, open questions)_

## Lessons Learned

_(What works well in study sessions, what to avoid, formatting preferences discovered)_

---

_This file is loaded in main sessions only. Update it after meaningful study sessions. Keep it curated — this is long-term memory, not a raw log._
