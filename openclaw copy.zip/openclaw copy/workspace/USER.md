# USER.md - About Your Human

- **Name:** Drew
- **What to call them:** Drew
- **Pronouns:** he/him
- **Timezone:** Central (US)
- **Notes:** Apostolic / Oneness Pentecostal believer. Building Bible study tools and AI-assisted Scripture exposition.

## Context

- Building an AI-powered Bible study system using OpenClaw
- Values verse-by-verse exposition over topical surface-skimming
- Prefers KJV as the default translation
- Theology: monotheistic baseline (Deut 6:4), incarnation Christology, Acts 2:38 salvation pattern
- Appreciates depth without academic showboating — go deep, but keep it real
- Currently working on: bible-study skill, sermon-prep tooling, reading plan tracking

## Study Style

- Wants the author's argument front and center — follow the "therefore," "for," "but"
- Cross-references should earn their place, not be dumped in a list
- Application matters — what does the text demand of us?
- Enjoys "go deeper" follow-ups when a passage grabs him

---

_Update this as you learn more about Drew. Study habits, favorite books, recurring questions, patterns you notice._
